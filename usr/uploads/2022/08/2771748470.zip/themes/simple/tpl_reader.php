<?php if (!defined('__ROOT_DIR__')) exit; ?>

<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="shenma-site-verification" content="264dbd1d5240d158489fa058761a3b66_1574730302">
    <meta name="robots" content="all"><meta name="googlebot" content="all"><meta name="baiduspider" content="all">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0" />
    <title><?=$articlename?>(<?=$author?>著)_<?=$chaptername?>_<?=$sortname?>小说_<?=SITE_NAME?></title>
    <link rel="canonical" href="https://www.7shuge.com<?=$uri?>">
    <meta name="keywords" content="<?=$chaptername?>,<?=$articlename?>最新章节,<?=$articlename?>免费阅读,<?=$author?>著">
    <meta name="description" content="<?=$chaptername?>:<?=$reader_des?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?=$site_url?>/static/<?=$theme_dir?>/favicon.ico" media="screen">

    <script src="/static/<?=$theme_dir?>/user.js"></script>
    <style>
        #rtext p{
            text-indent: 2rem;
            margin: 2rem 0;
        }
    </style>
</head>
<?php require_once 'tpl_header.php'; ?>

<div class="container">
	<div class="content">
		<ol class="breadcrumb">
            <li><a href="/" title="<?=SITE_NAME ?>">首页</a></li>
            <li><a href="<?=Sort::ss_sorturl($sortid)?>"><?=$sortname?></a></li>
            <li><a href="<?=$info_url?>"><?=$articlename?></a></li>
            <li class="active"><?=$chaptername?></li>
        </ol>
		<div class="book read" id="acontent">
		<div class="fullbar"><script src="/static/<?=$theme_dir?>/pagetop.js"></script></div>
			<h1 class="pt10"><?=$chaptername?>（<?=$now_pid?> / <?=$max_pid?>）</h1>
			<p class="booktag">
                <a class="red" id="a_addbookcase" href="javascript:addbookcase('<?=$articleid?>','<?=$articlename?>','<?=$chapterid?>','<?=$chaptername?>')">加入书签</a>
            </p>
            <div class="readcontent" id="rtext"><?=$rico_content?> <a style="font-size:18px;" href="javascript:$('body,html').animate({scrollTop:0},100);">↑返回顶部↑</a></div>
			<p class="text-center">
                <!-- 上一页/上一章 -->
                <?php if($prevpage_url != ''): ?>
                    <a id="linkPrev" class="btn btn-default" href="<?=$prevpage_url?>">上一页</a>
                <?php else: ?>
                    <?php if($pre_cid == 0): ?><a id="linkPrev" class="btn btn-default" href="javascript:void(0);">书首页</a><?php else: ?><a id="linkPrev" class="btn btn-default" href="<?=$pre_url?>">上一章</a><?php endif ?>
                <?php endif ?>
                <!-- 返回目录 -->
                <a id="linkIndex" class="btn btn-default" href="<?=$info_url?>"  disable="disabled">书页/目录</a> 
                <!-- 下一页/下一章 -->
                <?php if($nextpage_url != ''): ?>
                    <a id="linkNext" class="btn btn-default" href="<?=$nextpage_url?>">下一页</a>
                <?php else: ?>
                    <?php if($next_cid == 0): ?><a id="linkNext" class="btn btn-default" href="javascript:void(0);">书末页</a><?php else: ?><a id="linkNext" class="btn btn-default" href="<?=$next_url ?>">下一章 </a><?php endif ?>
                <?php endif ?>
            </p>
			<p class="pt10 text-center hidden-xs">温馨提示：按 回车[Enter]键 返回书目，按 ←键 返回上一页， 按 →键 进入下一页，加入书签方便您下次继续阅读。</p>
			<div class="clear"></div>
		</div>
		<div class="book mt10 pt10 tuijian">
            <?=$sortname?>相关阅读：
                <?php include __ROOT_DIR__ . '/shipsay/include/neighbor.php'; foreach($neighbor as $v):?>
                    <a href="<?=$site_url?><?=$v['info_url'] ?>" title="<?=$articlename?>"><?=$v['articlename'] ?></a>
                <?php endforeach ?>
            <div class="clear"></div>
		</div>
		<p class="pt10 hidden-xs"><a href="<?=$info_url?>" title="<?=$articlename?>"><?=$articlename?></a>所有内容均来自互联网，<?=SITE_NAME ?>只为原作者<?=$author?>的小说进行宣传。欢迎各位书友支持<?=$author?>并收藏<a href="<?=$info_url?>" title="<?=$articlename?>"><?=$articlename?>最新章节</a>。</p>
	</div>
	<div class="clear"></div>
</div>
<script type="text/javascript">ReadKeyEvent();var lastread=new LastRead(); lastread.set('<?=$info_url?>', window.location.href, '<?=$articlename?>', '<?=$chaptername?>', '<?=$author?>', '<?=$sortname?>');</script>

<?php require_once __THEME_DIR__  . '/tpl_footer.php'; ?>
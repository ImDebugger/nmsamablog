<?php if (!defined('__ROOT_DIR__')) exit; ?>
<!-- footer -->
    <a href="/"><p style="text-align:center;margin:10px 0; color: #999;"><?=SITE_NAME?></p></a>
    <script src="//cdn.staticfile.org/jquery.lazyload/1.9.1/jquery.lazyload.min.js"></script>
    <script>lazy();count();</script>
</body>
</html>
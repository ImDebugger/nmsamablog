<?php if (!defined('__ROOT_DIR__')) exit;?>

<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title><?=$articlename?>(<?=$author?>)_<?=$articlename?>全文免费阅读无弹窗_<?=$sortname?>_<?=SITE_NAME?></title>
    <meta name="keywords" content="<?=$articlename?>,<?=$year?><?=$articlename?>最新章节,<?=$articlename?>免费阅读,<?=$author?>著,<?=$isfull?>">
    <meta name="description" content="<?=$articlename?>,<?=$year?><?=$articlename?>小说阅读,<?=$sortname?>类型小说,<?=$articlename?>由作家<?=$author?>创作,<?=$intro_des?><?=SITE_NAME?>提供<?=$articlename?>最新章节,<?=$articlename?>最新更新章节,<?=SITE_NAME?>免费稳定急速专业无弹窗">
    <meta property="og:type" content="novel">
    <meta property="og:title" content="<?=$articlename?>(<?=$author?>)_<?=$articlename?>全文免费阅读无弹窗_<?=$sortname?>_<?=SITE_NAME?>">
    <meta property="og:image" content="<?=$img_url?>">
    <meta property="og:description" content="<?=$articlename?>,<?=$articlename?>小说阅读,<?=$sortname?>类型小说,<?=$articlename?>由作家<?=$author?>创作,<?=$intro_des?><?=SITE_NAME?>提供<?=$articlename?>最新章节,<?=$articlename?>最新更新章节,<?=SITE_NAME?>免费稳定急速专业无弹窗">
    <meta property="og:novel:category" content="<?=$sortname?>">
    <meta property="og:novel:author" content="<?=$author?>">
    <meta property="og:novel:author_link" content="<?=$site_url?><?=$author_url?>">
    <meta property="og:novel:book_name" content="<?=$articlename?>">
    <meta property="og:novel:read_url" content="<?=$site_url?><?=$uri?>">
    <meta property="og:novel:url" content="<?=$site_url?><?=$uri?>">
    <meta property="og:novel:status" content="<?=$isfull?>">
    <meta property="og:novel:update_time" content="<?=$lastupdate?>">
    <meta property="og:novel:lastest_chapter_name" content="<?=$lastchapter?>">
    <meta property="og:novel:lastest_chapter_url" content="<?=$site_url?><?=$last_url?>">
<?php require_once __ROOT_DIR__ . '/shipsay/include/neighbor.php';require_once 'tpl_header.php'; ?>
<script src="/static/<?=$theme_dir?>/user.js"></script>

<div id="main">
<div id="maininfo">
<div class="coverecom w_770 left">
<div class="tabstit">
<span class="label"></span><a href="/"><?=SITE_NAME?></a><i>＞</i><a href="<?=Sort::ss_sorturl($sortid)?>"><?=$sortname?></a><em>＞</em><em><?=$articlename?></em>
</div>
<img src="<?=$img_url?>" class="book-cover-blur hide" alt="<?=$articlename?>">
<div id="bookinfo">
<div class="bookleft">
<div id="bookimg">
<img alt="<?=$articlename?>" src="<?=$img_url?>" width="152" height="195" />
</div>
</div>
<div class="bookright">
<div class="d_title">
<h1><?=$articlename?></h1>
<span class="p_author">作者：<a href="/author/<?=$author?>/" target="_blank"><?=$author?></a></span>
</div>
<div id="count">
<ul>
<li><strong>分类：</strong><span><?=$sortname?></span></li>
<li><strong>字数：</strong><span><?=$words_w?> 万</span></li>
<li><strong>状态：</strong><span><?=$isfull?></span></li>
<li id="uptime"><strong>更新：</strong><span><?=date('Y-m-d', strtotime($lastupdate))?></span></li>
</ul>
</div>
<div style="clear:both"></div>
<div id="bookintro" class="hm-scroll"><?=$intro_p?></div>
<div style="clear:both"></div>
</div>
<div id="button_all">
<ul>
<li class="b1"><a rel="nofollow" href="<?=$first_url?>">开始阅读</a></li>
<li class="b2"><a rel="nofollow" href="javascript:addbookcase('<?=$articleid?>','<?=$articlename?>')">加入书架</a></li>
<li class="b2d"><a href="javascript:alert('敬请期待');">催更报错</a></li>
</ul>
<div style="clear:both"></div>
</div>
</div>
</div>
<div class="list_center w_200 right">
<div class="update_title">
<span class="update_icon">新书推荐</span>
</div>
<div class="hotlist">
<ul>
    <?php
        $sql = $rico_sql . ' AND sortid = '. $sortid . ' ORDER BY postdate DESC LIMIT 10';
        if(isset($redis)) {
            $sortpost = $redis->ss_redis_getrows($sql, $info_cache_time);
        } else {
            $sortpost = $db->ss_getrows($sql);
        }
    foreach($sortpost as $k => $v) { ?>
            <li><strong><?=$v['author'] ?></strong><span>[<?=$v['sortname_2'] ?>]</span><a href="<?=$v['info_url'] ?>"><?=$v['articlename'] ?></a></li>
    <?php } ?>
</ul>
</div>
</div>
<div class="clearfix"></div>
</div>
<div id="newlist">
<div class="newrap">
<h2><?=$articlename?>最新章节</h2><i class="dispc">（提示：已启用缓存技术，最新章节可能会延时显示，登录书架即可实时查看）</i>
</div>
<ul class="chaw">
    <?php if($lastarr != ''): ?><?php foreach($lastarr as $k => $v): ?>
        <li><a href="<?=$v['cid_url'] ?>"><?=$v['cname'] ?></a></li>
    <?php endforeach ?><?php endif ?>
</ul>

<div class="newrap_c">
<h2><?=$articlename?>全文阅读</h2><span onclick="desc(this);">倒序 ↑</span>
</div>
<ul class="chaw_c" id="chapterList">
    <?php if($chapterrows != ''): ?><?php foreach($chapterrows as $k => $v): ?>
        <li><a href="<?=$v['cid_url'] ?>"><?=$v['cname'] ?></a></li>
    <?php endforeach ?><?php endif ?>
</ul>
</div>
<i class="lbxxyx_s">章节目录</i>
<div id="product">
<h2>精品小说</h2>
<ul>
    <?php foreach($neighbor as $k => $v) { if($k<8) { ?>
        <li><a href="<?=$v['info_url'] ?>"><img src="<?=$v['img_url'] ?>" alt="<?=$v['articlename'] ?>" width="100" height="140"></a><a href="<?=$v['info_url'] ?>"><h3><?=$v['articlename'] ?></h3></a></li>
    <?php }} ?>
</ul>
<div class="prodlist">
<ol>
    <?php
        $sql = $rico_sql . ' ORDER BY dayvisit DESC LIMIT 24';
        if(isset($redis)) {
            $dayvisit = $redis->ss_redis_getrows($sql, $info_cache_time);
        } else {
            $dayvisit = $db->ss_getrows($sql);
        }
    foreach($dayvisit as $k => $v) { ?>
            <li><span>[<?=$v['sortname']?>]</span><a href="<?=$v['info_url']?>"><?=$v['articlename']?></a></li>
    <?php } ?>
</ol>
</div>
</div>
</div>
<?php require_once 'tpl_footer.php'; ?>










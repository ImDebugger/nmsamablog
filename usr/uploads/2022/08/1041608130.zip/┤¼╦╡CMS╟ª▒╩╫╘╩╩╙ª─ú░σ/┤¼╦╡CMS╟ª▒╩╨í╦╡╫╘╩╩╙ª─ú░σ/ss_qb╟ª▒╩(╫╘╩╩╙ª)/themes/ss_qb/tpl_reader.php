
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=$articlename?>-<?=$chaptername?>_<?=SITE_NAME?></title>
<meta name="keywords" content="<?=$articlename?>,<?=$chaptername?>" />
<meta name="description" content="<?=$articlename?>是作者<?=$author?>所著的<?=$sortname?>类小说，本章节为<?=$chaptername?>。更多《<?=$articlename?>》章节请到「<?=SITE_NAME?>网」免费全文在线阅读..." />
<meta property="og:url" content="<?=$uri?>" id="ogurl" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="applicable-device" content="pc,mobile" />
<meta http-equiv="mobile-agent" content="format=html5;url=<?=$uri?>" />
<meta http-equiv="mobile-agent" content="format=xhtml;url=<?=$uri?>" />
<meta http-equiv="Cache-Control" content="no-transform" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="renderer" content="webkit">
<link rel="stylesheet" href="/static/<?=$theme_dir?>/reader.css" />
<script src="https://cdn.staticfile.org/jquery/1.8.3/jquery.min.js"></script>
<script src="https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="/static/<?=$theme_dir?>/user.js"></script>
<?php $tempvar = is_mobile() ? 'motheme' : 'pctheme'; echo '<script src="/static/' . $theme_dir . '/' . $tempvar. '.js"></script>' ;?>

</head>
<body class="bg6" id="readbg" onselectstart="return false">

<div class="top">
    <div class="bar">
        <div class="chepnav">
            <i>当前位置:</i><a href="/"><?=SITE_NAME?></a>><a href="<?=Sort::ss_sorturl($sortid)?>"><?=$sortname?></a>><a href="<?=$info_url?>"><?=$articlename?></a>> <em><?=$chaptername?></em>
        </div>
        <ul><div class="unloginl"><script>login();</script></div></ul>
    </div>
</div>

<div class="mlfy_main">

<?php if(!is_mobile()) :?>

    <div class="container">
        <ul class="links">
            <li><a href="javascript:addbookcase('<?=$articleid?>','<?=$articlename?>','<?=$chapterid?>','<?=$chaptername?>')">标记书签</a> | </li>
            <li><a href="javascript:alert('敬请期待')" style="color:red">章节报错</a> | </li>
            <li><a href="/recentread/">阅读记录</a></li>
        </ul>
        <div class="mlfy_main_l"><i class="szk"><em class="icon-cog"></em> <z>阅读</z>设置</i><i class="hid">（推荐配合 快捷键[F11] 进入全屏沉浸式阅读）</i></div>
    </div>
    <div class="mlfy_main_sz b2" >
        <p class="ml"><span class="txt">设置</span><span class="close">X</span></p>
        <ul>
            <li><span class="fl">阅读主题</span><i class="c1"></i><i class="c2"></i><i class="c3"></i><i class="c4"></i><i class="c5"></i><i class="c6 hover"></i><i class="c7"></i><i class="c8"></i></li> 
            <li class="hid"><span class="fl">正文字体</span><span class="zt hover">雅黑</span><span class="zt">宋体</span><span class="zt">楷体</span><span class="zt" title="方正启体简体">启体</span><span class="zt" title="思源黑体 CN">思源</span><span class="zt" title="苹方字体">苹方</span></li>
            <li><span class="fl">字体大小</span><span class="dx dxl">A-</span><span class="dx dxc">20</span><span class="dx dxr">A+</span></li><li class="hid"><span class="fl">页面宽度</span><p class="dx kdl"><span class="icon"></span><span class="fl">-</span></p><p class="dx kdc">100%</p><p class="dx kdr"><span class="icon"></span><span class="fl">+</span></p></li>
        </ul>
        <div class="btn-wrap"><a class="red-btn" href="javascript:">保存</a><a class="grey-btn"   href="javascript:">取消</a></div>
    </div>
<?php endif ?>


<div id="mlfy_main_text">
    <h1><?=$chaptername?>（<?=$now_pid?> / <?=$max_pid?>）</h1>
    <dt class="tp"></dt>
    <dt class="kw"></dt>

<?php if(is_mobile()) :?>
    <div class="toolbar">
        <div class="theme" style="float: left;width: auto;height: auto;">
            <span>
                <a href="javascript:addbookcase('<?=$articleid?>','<?=$articlename?>','<?=$chapterid?>','<?=$chaptername?>')">添加书签</a>
                <a href="javascript:alert('敬请期待')" style="color: red;">章节报错</a>
                <a href="/recentread/">阅读记录</a>
            </span>
        </div>
        <a href="javascript:;" class="aminus font_dec" id="font_dec"></a>
        <a href="javascript:;" class="aadd font_inc" id="font_inc"></a>
        <a href="javascript:;" class="pattern menu-moon" id="mode"></a>
        <div class="option theme">
            <div class="theme-area theme-pink" id="theme2"></div>
        </div>
        <div class="cr"></div>
    </div>
<?php endif ?>



    <div id="TextContent" class="read-content"><?=$rico_content?></div>
</div>
</div>
</div>
<p class="mlfy_page">
    <!-- 上一页/上一章 -->
    <?php if($prevpage_url != ''): ?>
    <a id="prev_url" href="<?=$prevpage_url?>">上一页</a>
    <?php else: ?>
        <?php if($pre_cid == 0): ?><a id="prev_url" href="javascript:void(0);">没有了</a><?php else: ?><a id="prev_url" href="<?=$pre_url?>">上一章</a><?php endif ?>
    <?php endif ?>
    <a id="info_url" href="<?=$info_url?>">目录</a>
    <a href="javascript:addbookcase('<?=$articleid?>','<?=$articlename?>','<?=$chapterid?>','<?=$chaptername?>')">+书签</a>
    <?php if($nextpage_url != ''): ?>
        <a id="next_url" href="<?=$nextpage_url?>">下一页</a>
    <?php else: ?>
        <?php if($next_cid == 0): ?><a id="next_url" href="javascript:void(0);">没有了</a><?php else: ?><a id="next_url" href="<?=$next_url ?>">下一章 </a><?php endif ?>
    <?php endif ?>
 </p>

<script src="/static/<?=$theme_dir?>/tempbookcase.js"></script>

<script>
    <?php if(!is_mobile()) :?>yuedu();<?php endif?>
    lastread.set('<?=$info_url?>', window.location.href, '<?=$articlename?>', '<?=$chaptername?>', '<?=$author?>', '<?=$img_url?>');   
    const preview_page = $('#prev_url').attr('href');
    const index_page = $('#info_url').attr('href');
    const next_page = $('#next_url').attr('href');
    function jumpPage(){
        const event = document.all ? window.event : arguments[0];
        if (event.keyCode == 37) document.location = preview_page;
        if (event.keyCode == 39) document.location = next_page;
        if (event.keyCode == 13) document.location = index_page;
        }
        document.onkeydown = jumpPage;
</script>


</body>
</html>
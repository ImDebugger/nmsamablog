<?php if (!defined('__ROOT_DIR__')) exit; ?>

<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
    <title>好看的<?php if($sortname != ''):?><?=$sortname?>小说txt下载<?php endif ?><?php if($fullflag):?>已完本小说<?php endif ?>_<?=SITE_NAME?></title>
    <meta name="keywords" content="<?php if($sortname == ''):?>分类列表,小说全部分类列表,小说书库<?php else:?><?=$sortname?>,<?=$sortname?>类型推荐,<?=$year?>热门的<?=$sortname?>小说,<?=$sortname?>的分类列表,<?=$sortname?>的小说书库<?php endif ?>">
    <meta name="description" content="<?php if($sortname == ''):?>分类列表,小说全部分类列表,小说书库<?php else:?><?=$sortname?>,<?=$sortname?>类型推荐,<?=$year?>热门的<?=$sortname?>小说,<?=$sortname?>的分类列表,<?=$sortname?>的小说书库,<?=SITE_NAME?>为你提供免费无弹窗的阅读体验<?php endif ?>">
<?php require_once 'tpl_header.php'; ?>

<div id="main">
<div id="maininfo">
<div id="listtop">
<div class="list">
<h2>热力推荐</h2>
<div class="recombook">
    <?php foreach($retarr as $k => $v) { if($k<4){?>

    <dl>
    <dt><a href="<?=$v['info_url']?>"><img class="lazy" src="<?=Url::nocover_url()?>" data-original="<?=$v['img_url']?>" alt="<?=$v['articlename']?>" height="158" width="128"></a></dt>
    <dd><a href="<?=$v['info_url']?>"><h3><?=$v['articlename']?></h3></a></dd>
    <dd class="tit"><span>作者：</span><?=$v['author']?></dd>
    <dd class="name"> <?=$v['intro_des']?></dd>
    </dl>
    <?php }} ?>

</div>
</div>
<div class="listbox">
<h2>本周强推</h2>
<?php
    $sql = $sortid > 0 ? $rico_sql.'AND sortid = '. $sortid : $rico_sql;
    $sql .= ' ORDER BY weekvisit DESC LIMIT 10';
    if(isset($redis)) {
        $weekvisit10 = $redis->ss_redis_getrows($sql, $home_cache_time);
    } else {
        $weekvisit10 = $db->ss_getrows($sql);
    }
?>
<div class="recombook">
<dl>
    <?php foreach($weekvisit10 as $k => $v) {if($k < 1 ){ ?>
        <dt><a href="<?=$v['info_url']?>" target="_blank"><img class="lazy" src="<?=Url::nocover_url()?>" data-original="<?=$v['img_url']?>" alt="<?=$v['articlename']?>" width="112" height="140" /></a></dt>
        <dd><a href="<?=$v['info_url']?>" target="_blank"><h3><?=$v['articlename']?></h3></a></dd>
        <dd class="name"><?=$v['intro_des']?></dd>
    <?php }} ?>
</dl>
<?php foreach($weekvisit10 as $k => $v) {if($k >=1 ){ ?>

    <li><h3>[<?=$v['sortname']?>] <a href="<?=$v['info_url']?>" title="<?=$v['articlename']?>" target="_blank"><?=$v['articlename']?></a></h3></li>

<?php }} ?>

</div>
</div>
</div>
<div class="clearfix"></div>
<div class="list_center">
<div class="update_title">
<span class="update_icon"><?=$v['sortname']?>·小说列表</span>
</div>
<div id="sitebox">
    <?php foreach($retarr as $k => $v) {if($k >=4 ){ ?>
        <dl>
            <dt><a href="<?=$v['info_url']?>"><img class="lazy" src="<?=Url::nocover_url()?>" data-original="<?=$v['img_url']?>" alt="<?=$v['articlename']?>" height="150" width="107"></a><span><?=$v['sortname']?></span></dt>
            <dd><h3><span class="uptime"><?=date('Y-m-d', $v['lastupdate'])?></span><a href="<?=$v['info_url']?>"><?=$v['articlename']?></a></h3></dd>
            <dd class="book_other">子类：<span><?=$v['sortname']?></span>状态：<span><?=$v['isfull']?></span>字数：<span><?=$v['words']?></span></dd>
            <dd class="book_des"><?=$v['intro_des']?></dd>
            <dd class="book_other">最新章节：<a href="<?=$v['last_url']?>"><?=$v['lastchapter']?></a></dd>
        </dl>
    <?php }} ?>
    <div class="clearfix"></div>
</div>

<div class="pages"><div class="pagelink" id="pagelink"><?=$jump_html ?></div>
</div>
</div>
</div>
</div>
<?php if($sortid>0): ?>
    <script>$('.nav li:nth-child(<?=$sortid+1?>)').css('background', '#5E8E9E');</script>
<?php else: ?>
    <script>$('.nav li:nth-last-child(2)').css('background', '#5E8E9E');</script>
<?php endif ?>
<?php require_once 'tpl_footer.php'; ?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><?=SITE_NAME?>_最值得书友收藏的网络小说阅读网</title>
<meta name="keywords" content="圣虚,网络小说,小说,全本小说,<?=SITE_NAME?>" />
<meta name="description" content="<?=SITE_NAME?>是广大书友最值得收藏的网络小说阅读网.网站收录了当前最火热的网络小说,平台上的所有文学作品均来源于热心用户的积极上传.分享小说,享受阅读乐趣!" />

<?php require_once 'tpl_header.php';?>
<script>$('.nav li:nth-child(1)').css('background', '#5E8E9E');</script>


<div class="topa"><script>topa();</script></div>
<div id="main">
    <div class="coverecom mbottom">
        <div class="tabstit_index">
        <span class="label"></span><em>好书推荐</em>
        </div>
        <div class="recombook">
            <?php if(is_array($commend)){ foreach($commend as $k => $v) { if($k < 6) { ?>
                <dl>
                    <dt><a href="<?=$v['info_url']?>"><img class="lazy" src="<?=Url::nocover_url()?>" data-original="<?=$v['img_url']?>" alt="<?=$v['articlename']?>" height="158" width="128"></a></dt>
                    <dd><a href="<?=$v['info_url']?>"><?=$v['articlename']?></a></dd>
                    <dd class="tit"><span>作者：</span><?=$v['author']?></dd>
                    <dd class="name"><?=$v['intro_des']?></dd>
                </dl>        
            <?php }}} ?>
        </div>
    </div>

    <!-- 八个分类列表 -->
    <?php for( $i = 1; $i <= 8; $i++) : $tmpvar = 'sort'.$i ?>
            <div class="coverecom w_440 <?php if($i % 2 == 1) {echo 'left'; } else { echo 'right';} ?>  mbottom">
        <div class="tabstit"><span class="label"></span><em><?=Sort::ss_sortname($i,1)?></em></div>
        <div class="recomclass">
            <?php foreach ($$tmpvar as $k => $v) { if ($k < 2) { ?>
                <dl>
                    <dt><a href="<?=$v['info_url']?>"><img class="lazy" src="<?=Url::nocover_url()?>" data-original="<?=$v['img_url']?>" alt="<?=$v['articlename']?>"></a></dt>
                    <dd><a href="<?=$v['info_url']?>"><?=$v['articlename']?></a></dd>
                    <dd class="tit">作者：<?=$v['author']?></dd>
                    <dd class="name"><?=$v['intro_des']?></dd>
                </dl>
            <?php }} ?>
                <ul>
                    <?php foreach ($$tmpvar as $k => $v) { if ($k > 2 && $k < 12) { ?>
                        <li><em><?=$v['author']?></em><span>[<?=$v['sortname']?>]</span><a href="<?=$v['info_url']?>"><?=$v['articlename']?></a></li>
                    <?php }}?>
                </ul>
        </div>
    </div>
    <?php endfor ?>

    <div class="clearfix"></div>

</div> <!-- main -->

<div id="index_last">
<div class="list_center w_770 left">
<div class="update_title">
<span class="update_icon">更新列表</span>

</div>
<div class="update_list">
<ul>
    <?php foreach($lastupdate as $k => $v) { if($k < 20) { ?>	
        <li><span class="recnums_r">[<?=$v['sortname']?>]</span><span class="r_spanone"><a href="<?=$v['info_url']?>"><?=$v['articlename']?></a></span><span class="r_spantwo"><a href="<?=$v['last_url']?>"><?=$v['lastchapter']?></a></span><span class="r_spanthree"><?=date('m-d',$v['lastupdate'])?></span><span class="r_spanfour"><?=$v['author']?></span></li>
    <?php }} ?>
</ul>
</div>
</div>
<div class="list_center w_200 right">
<div class="update_title">
<span class="update_icon">新书推荐</span>
</div>
<div class="bookList">
<ul>
    <?php foreach($postdate as $k => $v) { if($k < 20) { ?>
        <li><strong><?=$v['author']?></strong><span class="resort">[<?=$v['sortname_2']?>]</span><a href="<?=$v['info_url']?>"><?=$v['articlename']?></a></li>
    <?php }} ?>
</ul>
</div>
</div>
<div class="clearfix"></div>
</div>
<div id="footer" class="dispc">
    <div class="friendLink">
        <h3 class="linkMenu">友情链接</h3>
        <div class="linkInfo">
            <a href="https://www.shipsay.com" target="_blank">船说主页</a>
            <a href="https://www.shipsay.com" target="_blank">船说主页</a>
        </div>
    </div>
    <p class="copyright">
        <span>本网站为网友提供小说上传储存空间平台，为网友提供在线阅读交流、txt下载，平台上的所有文学作品均来源于网友的上传<br />
用户上传的文学作品均由网站程序自动分割展现，无人工干预，本站自身不编辑或修改网友上传的内容（请上传有合法版权的作品）<br />
如发现本站有侵犯权利人版权内容的，请向本站投诉，一经核实，本站将立即删除相关作品并对上传人ID账号作封号处理<br />
        </span>
    </p>
</div>

<?php require_once 'tpl_footer.php';?>



<?php if (!defined('__ROOT_DIR__')) exit; ?>

<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<title>搜索结果_<?=SITE_NAME?>_书友最值得收藏的网络小说阅读网</title>
<meta name="keywords" content="<?=SITE_NAME?>,免费小说网,手机小说,最新小说推荐,小说阅读网,免费小说阅读网,小说阅读器全本免费小说,小说网站排名,小说在线阅读" />
<meta name="description" content="<?=SITE_NAME?>收集了{<?=$year?>网络热门小说的最新章节免费阅读,提供玄幻、武侠、原创、网游、都市、言情、历史、军事、科幻、恐怖、官场、穿越、重生等小说,{<?=$year?>最新全本免费手机小说阅读推荐,一切精彩尽在<?=SITE_NAME?>" />
<?php require_once 'tpl_header.php'; ?>


<div id="main">
<div class="list_center">
<div class="update_title" style="text-align:center;">
<span class="update_icon">搜索"<?=$searchkey?>" 共有 "<?=$search_count?>" 个结果</span>
</div>
<div id="sitebox">
    <?php if($search_count == 0): ?>
        <div id="tipss" class="tipss">抱歉，没有找到你想要的小说<br />请确认小说名字并尽可能的<br /><br />△ <em style="color: red;font-size: 16px;font-weight:bold;font-style:normal">减少关键词字数，如：重生</em> △<br /><br /><em style="color: red;font-style:normal">※ 不支持繁体搜索，请输入简体字 ※</em></div>
    <?php else :?>
        <?php foreach($search_res as $k => $v): ?>
            <dl id="nr">
            <dt><a href="<?=$v['info_url']?>"><img class="lazy" src="<?=Url::nocover_url()?>" data-original="<?=$v['img_url']?>" alt="<?=$v['articlename']?>" height="150" width="107"></a><span><?=$v['sortname']?></span></dt>
            <dd><h3><span class="uptime"><?=date('Y-m-d',$v['lastupdate'])?></span><a href="<?=$v['info_url']?>"><?=$v['articlename']?></a></h3></dd>
            <dd class="book_other">作者：<span><?=$v['author']?></span>子类：<span><?=$v['sortname']?></span>字数：<span><?=$v['words']?></span></dd>
            <dd class="book_des"><?=$v['intro_des']?></dd>
            <dd class="book_other">最新章节：<a href="<?=$v['last_url']?>"><?=$v['lastchapter']?></a></dd>
            </dl>
	    <?php endforeach ?>
    <?php endif; ?>

    <div class="clearfix"></div>
</div>
</div>
<style>.tipss{text-align:center; display:none; padding:30px 0px;background: #fff;font-size:14px;}</style>
<style>@media screen and (max-width:768px){.tipss{width: 100%;border: none;}}</style>
<script>if(document.getElementById("nr") == null ){ document.getElementById("tipss").style.display = "block";}</script>

<?php require_once 'tpl_footer.php'; ?>


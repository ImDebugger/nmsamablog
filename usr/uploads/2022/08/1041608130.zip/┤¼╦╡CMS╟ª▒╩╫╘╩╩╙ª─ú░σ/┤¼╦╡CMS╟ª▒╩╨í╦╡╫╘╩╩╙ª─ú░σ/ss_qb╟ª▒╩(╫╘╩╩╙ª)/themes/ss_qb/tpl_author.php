<?php if (!defined('__ROOT_DIR__')) exit; ?>

<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
    <title><?=$author?>,<?=$author?>新书,<?=$author?>小说大全 - <?=SITE_NAME?></title>
    <meta name="keywords" content="<?=$author?>,<?=$author?>新书,<?=$author?>小说大全,<?=SITE_NAME?>">
    <meta name="description" content="本站提供大量好看的免费小说、玄幻小说、穿越小说等各种好看的小说，小说排行榜每日更新各类小说居同类小说网站之首，是小说迷们最喜欢的全本小说阅读网！">

<?php require_once 'tpl_header.php'; ?>

<div id="main">
    <div class="list_center">
        <div class="update_title">
            <h1><?=$author?>新书作品小说全集</h1>
        </div>
    <div id="sitebox">
        <?php foreach($res as $k => $v): ?>
            <dl id="nr">
            <dt><a href="<?=$v['info_url']?>"><img class="lazy" src="<?=Url::nocover_url()?>" data-original="<?=$v['img_url']?>" alt="<?=$v['articlename']?>" height="150" width="107"></a><span><?=$v['sortname']?></span></dt>
            <dd><h3><span class="uptime"><?=date('Y-m-d',$v['lastupdate'])?></span><a href="<?=$v['info_url']?>"><?=$v['articlename']?></a></h3></dd>
            <dd class="book_other">作者：<span><?=$v['author']?></span>子类：<span><?=$v['sortname']?></span>字数：<span><?=$v['words']?></span></dd>
            <dd class="book_des"><?=$v['intro_des']?></dd>
            <dd class="book_other">最新章节：<a href="<?=$v['last_url']?>"><?=$v['lastchapter']?></a></dd>
            </dl>
        <?php endforeach ?>
    <div class="clearfix"></div>

<br></div>
</div>

<?php require_once 'tpl_footer.php'; ?>

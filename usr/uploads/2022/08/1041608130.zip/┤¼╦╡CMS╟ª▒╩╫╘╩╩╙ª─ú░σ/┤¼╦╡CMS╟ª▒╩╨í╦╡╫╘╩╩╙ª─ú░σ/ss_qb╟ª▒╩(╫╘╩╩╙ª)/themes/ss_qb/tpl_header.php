<?php if (!defined('__ROOT_DIR__')) exit; ?>

<!-- header -->
<meta name="robots" content="all"><meta name="googlebot" content="all"><meta name="baiduspider" content="all">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0" />
    <link rel="shortcut icon" type="image/x-icon" href="/static/<?=$theme_dir?>/favicon.ico" media="screen">
    <link rel="stylesheet" href="/static/<?=$theme_dir?>/style.css" />
	<script src="https://cdn.staticfile.org/jquery/1.8.3/jquery.min.js"></script>
	<script src="https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
    <script src="/static/<?=$theme_dir?>/common.js"></script>
    <script src="/static/<?=$theme_dir?>/user.js"></script>
</head>

<body>
<div class="top">
<div class="bar">
<span class="loginSide"><a href="#">收藏本站（ Ctrl+D ）</a></span>
<ul><script>login();</script></ul>
</div>
</div>
<div id="header">
<div class="wrap980">
<div class="logo"><a href="/"><h1><?=SITE_NAME?></h1><span><?=SITE_URL?></span></a></div>
<div class="search">
<form id="search" name="t_frmsearch" method="post" action="/search/" >
    <span class="searchBox"><input name="searchkey" type="text" placeholder="关键字，如：重生" autocomplete="off" /></span>
    <button type="submit" class="serBtn">搜索</button>
</form>

<div class="hot" style="margin-left:70px;">热搜：
    <a href="/author/我吃西红柿/" target="_blank">我吃西红柿</a>
    <a href="/author/猫腻/" target="_blank">猫腻</a>
    <a href="/author/唐家三少/" target="_blank">唐家三少</a>
	<a href="https://www.52hwl.com" target="_blank">更多船说模板</a>
</div>
</div>
<div class="clearfix"></div>
</div>
<div class="nav">
    <ul>
        <li><a id="shouye" href="/">首页</a></li>
        <?php foreach(Sort::ss_sorthead() as $k => $v): ?>
            <li><a id="sort<?=$k+1?>" href="<?=$v['sorturl']?>"><?=$v['sortname']?></a></li>
        <?php endforeach ?>
        <li><a id="bookall" href="<?=$allbooks_url?>">书库</a></li>
        <li><a id="paihang" href="/recentread/">阅读记录</a></li>
    </ul>
</div>
</div>
<!-- /header -->

<?php if (!defined('__ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<title>最近阅读_<?=SITE_NAME?></title>
<meta name="keywords" content="<?=SITE_NAME?>,免费小说网,手机小说,最新小说推荐,小说阅读网,免费小说阅读网,小说阅读器全本免费小说,小说网站排名,小说在线阅读" />
<meta name="description" content="<?=SITE_NAME?>收集了<?=$year?>网络热门小说的最新章节免费阅读,提供玄幻、武侠、原创、网游、都市、言情、历史、军事、科幻、恐怖、官场、穿越、重生等小说,<?=$year?>最新全本免费手机小说阅读推荐,一切精彩尽在<?=SITE_NAME?>" />
<script src="/static/<?=$theme_dir?>/tempbookcase.js"></script>
<?php require_once 'tpl_header.php'; ?>
<script>$('.nav li:nth-last-child(1)').css('background', '#5E8E9E');</script>
<div class="user_right">
    <div style="background: #F7F7F7; padding: 8px 0px; font-size: 14px; text-align: center; font-weight: bold; border-bottom: 1px solid #E6E6E6;">阅读记录</div>
    <div class="r_2">
        <div id="history">
            <ul id="tempBookcase"></ul>
        </div>
    </div>
</div>
<script>showtempbooks();</script></div>
<?php require_once 'tpl_footer.php'; ?>

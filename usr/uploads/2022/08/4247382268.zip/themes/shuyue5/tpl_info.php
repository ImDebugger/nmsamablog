<?php if (!defined('__ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="cmn-Hans">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title><?=$articlename?>-<?=$author?>-全文免费阅读-<?=$articlename?>小说全集完整版大结局-<?=SITE_NAME?></title>
    <meta name="keywords" content="<?=$articlename?>,<?=$author?>,<?=$articlename?>最新章节,<?=$articlename?>全本" />
    <meta name="description" content="<?=$intro_des?>。<?=$articlename?>最新章节由网友<?=$author?>提供，《<?=$articlename?>》情节跌宕起伏、扣人心弦,是一本情节与文笔俱佳的好书,<?=SITE_NAME?>免费提供<?=$articlename?>无弹窗最新清爽干净的文字章节在线阅读。">
    <link rel="canonical" href="<?=$site_url?><?=$uri?>">
    <meta property="og:type" content="novel"/>
    <meta property="og:title" content="<?=$articlename?>"/>
    <meta property="og:description" content="<?=$intro_des?>"/>
    <meta property="og:image" content="<?=$site_url?><?=$img_url?>"/>
    <meta property="og:novel:category" content="<?=$sortname?>"/>
    <meta property="og:novel:author" content="<?=$author?>"/>
    <meta property="og:novel:book_name" content="<?=$articlename?>"/>
    <meta property="og:novel:read_url" content="<?=$site_url?><?=$uri?>"/>
    <meta property="og:url" content="<?=$site_url?><?=$uri?>"/>
    <meta property="og:novel:status" content="<?=$isfull?>"/>
    <meta property="og:novel:author_link" content="<?=$site_url?><?=$author_url?>">
    <meta property="og:novel:update_time" content='<?=$lastupdate?>' />
    <meta property="og:novel:latest_chapter_name" content="<?=$lastchapter?>"/>
    <meta property="og:novel:latest_chapter_url" content="<?=$site_url?><?=$last_url?>"/>
    <?php require_once 'tpl_header.php'; require_once __ROOT_DIR__ .'/shipsay/include/neighbor.php';?>
<div class="container body-content">
    <ol class="breadcrumb hidden-xs">
        <li><a href="/" title="<?=SITE_NAME?>"><i class="glyphicon glyphicon-home fs-14" aria-hidden="true"></i> 首页</a></li>
        <li><a href="<?=Sort::ss_sorturl($sortid)?>"><?=$sortname?></a></li>
        <li class="active"><?=$articlename?></li>
    </ol>
    <div class="panel panel-default">
        <div class="panel-body">
            <div class="row">
                <div class="col-sm-2 hidden-xs"><img class="img-thumbnail" alt="<?=$articlename?>" src="<?=$img_url?>" title="<?=$articlename?>" width="140" height="180" /></div>
                <div class="col-sm-10 pl0">
                    <h1 class="bookTitle"><?=$articlename?></h1>
                    <p class="booktag">
                        <a class="red" href="<?=$author_url?>" title="<?=$author?>"><i class="glyphicon glyphicon-user fs-12" aria-hidden="true"></i> <?=$author?></a>
                        <span class="blue"><i class="glyphicon glyphicon-font fs-12" aria-hidden="true"></i> <?=$words_w?>万字</span>
                        <span class="blue"><i class="glyphicon glyphicon-hourglass fs-12" aria-hidden="true"></i> <?=$isfull?></span>
                    </p>
                    <p id="bookIntro" class="text-justify">
                        <?=$intro_des?>
                    </p>
                    <hr/>
                    <div class="bookmore">
                        <a class="btn btn-danger" href="<?=$first_url?>" type="button" rel="nofollow"><i class="glyphicon glyphicon-eye-open" aria-hidden="true"></i> 全文阅读</a>
                        <a class="btn btn-success" href="javascript:addbookcase('<?=$articleid?>','<?=$articlename?>','<?=$chapterid?>','<?=$chaptername?>');" rel="nofollow" id="a_addbookcase" type="button"><i class="glyphicon glyphicon-heart-empty" aria-hidden="true"></i> 加入书架</a>
                        <div class="clear"></div>
                    </div>
                    <hr/>
                    <p>
                        最新章节：<a class="text-danger" href="<?=$last_url?>" title="<?=$lastchapter?>"><?=$lastchapter?></a>
                    </p>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading"><span class="glyphicon glyphicon-time" aria-hidden="true"></span> 最新章节列表</div>
        <dl class="panel-body panel-chapterlist">
            <?php if($lastarr != ''): ?><?php foreach($lastarr as $k => $v): ?>
                <dd class="col-sm-4"><a href="<?=$v['cid_url']?>"><?=$v['cname']?></a></dd>
            <?php endforeach ?><?php endif ?>
        </dl>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading"><span class="glyphicon glyphicon-book" aria-hidden="true"></span> 全部章节目录 <span onclick="javascript:reverse(this);">[点击倒序↓]</span></div>
        <dl class="panel-body panel-chapterlist" id="newlist">
            <?php foreach($chapterrows as $k => $v): ?>
                <dd class="col-sm-4"><a href="<?=$v['cid_url']?>"><?=$v['cname']?></a></dd>
            <?php endforeach ?>
            <div class="clear"></div>
        </dl>
    </div>
    <div class="panel panel-default">
        <div class="panel-body" style="text-align: center;"><a class="lbxxyx_s">打开全部目录 ▼</a></div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span> <?=$sortname?>小说相关阅读<a class="pull-right" href="<?=Sort::ss_sorturl($sortid)?>">More+</a>
        </div>
        <div class="panel-body">
            <div class="row">
                <?php foreach($neighbor as $k => $v): ?><?php if($k < 6):?>
                <div class="col-xs-4 book-coverlist">
                    <div class="row">
                        <div class="col-sm-5">
                            <a href="<?=$site_url?><?=$v['info_url']?>" class="thumbnail" style="background-image:url(<?=$v['img_url']?>)"></a>
                        </div>
                        <div class="col-sm-7 pl0">
                            <div class="caption">
                                <h4 class="fs-16 text-muted"><a href="<?=$site_url?><?=$v['info_url']?>" title="<?=$v['articlename']?>"><?=$v['articlename']?></a></h4>
                                <small class="fs-14 text-muted"><?=$v['author']?></small>
                                <p class="fs-12 text-justify hidden-xs"><?=$v['intro_des']?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif ?><?php endforeach ?>
                <div class="clear"></div>
            </div>
        </div>
    </div>
    <p class="hidden-xs">《<?=$articlename?>》所有内容均来自互联网或网友上传，<?=SITE_NAME?>只为原作者<?=$author?>的小说进行宣传。欢迎各位书友支持<?=$author?>并收藏《<?=$articlename?>》最新章节。</p>
    <div class="clear"></div>
</div>
<?php require_once 'tpl_footer.php'; ?>
<script>
    //隐藏显示
    $(function(){
        var _height = $('#newlist').height();
        if(_height <= 440){
            $('.lbxxyx_s').hide();
        }else{
            $('#newlist').height(440);
            $('#newlist').css({
                'height': '440px',
                'overflow': 'hidden'
            })
        }
        $('.lbxxyx_s').click(function(){
            var lbyxjs_height = $('#newlist').height();
            if(lbyxjs_height <= 440){
                $("#newlist").animate( { height: _height } ,"slow");
                $(this).html('收起目录 ▲');
            }else{
                $("#newlist").animate( { height:440} ,"slow");
                $(this).html('打开全部目录 ▼');
            }
        });
    });
    var isDesc=1;function reverse(obj){var that=this;var dl=$("#newlist");var list=dl.children();dl.empty();isDesc^=1;$(obj).text(isDesc?"[点击倒序↓]":"[点击正序↑]");for(var i=list.length-1;i>=0;i--){var copy=list.eq(i).clone();dl.append(copy)}}
</script>
<script src="/static/<?=$theme_dir?>/js/user.js"></script>
<script src="/static/<?=$theme_dir?>/js/layer.js"></script>

<?php if (!defined('__ROOT_DIR__')) exit; require_once __ROOT_DIR__ . '/shipsay/configs/report.ini.php';?>
<?php
$cateurl=$_SERVER['SERVER_PORT']==443?'https://':'http://';
$cateurl.=$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
?>
<?php require_once __ROOT_DIR__ .'/shipsay/include/neighbor.php';?>
<!DOCTYPE html>
<html lang="cmn-Hans">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title><?=$chaptername?>-<?=$articlename?>-<?=$author?>-<?=SITE_NAME?></title>
    <meta name="keywords" content="<?=$chaptername?>,<?=$articlename?>,<?=$author?>,<?=SITE_NAME?>" />
    <meta name="description" content="<?=$chaptername?>是<?=$author?>所著<?=$sortname?>小说《<?=$articlename?>》的最新章节，<?=SITE_NAME?>提供无弹窗阅读！">
    <link rel="canonical" href="<?=$cateurl?>">
    <meta http-equiv="Cache-Control" content="no-transform">
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="renderer" content="webkit">
    <meta name="applicable-device" content="pc,mobile">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="MobileOptimized" content="320">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="screen-orientation" content="portrait">
    <meta name="x5-orientation" content="portrait">
    <link href="https://cdn.staticfile.org/twitter-bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/<?=$theme_dir?>/css/site.css?v=<?=date("Ymd",time())?>" rel="stylesheet">
</head>
<body id="apage">
<header class="header_46f navbar navbar-inverse" id="header">
    <div class="con_46f container">
        <div class="navbar-header">
            <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            <a class="navbar-brand-left-none visible-xs" href="/"></a>
            <a class="navbar-brand hidden-xs" href="/"><?=SITE_NAME?></a>
            <a class="navbar-brand visible-xs" href="/"><?=SITE_NAME?></a>
        </div>
        <nav class="navbar_46f collapse navbar-collapse bs-navbar-collapse" role="navigation" id="nav-header">
            <ul class="nav navbar-nav nav_46f">
                <li class="46f_index"><a id="nav_index" href="/" style="">首页</a></li>
                <li class="46f_all"><a id="nav_sort" href="<?=$allbooks_url?>">书库</a></li>
                <li class="46f_top"><a id="nav_top" href="/rank/">排行</a></li>
                <li class="46f_over"><a id="nav_full" href="/quanben/sort/">全本</a></li>
                <li class="46f_bookcase"><a id="nav_his" href="<?=$fake_recentread?>">轨迹</a></li>
            </ul>
            <form class="search_46f navbar-form navbar-left" action="/search/" name="search" method="get">
                <div class="input-group">
                    <input type="text" class="form-control" size="10" maxlength="50" placeholder="搜索作品" name="searchkey" required>
                    <span class="input-group-btn"><button class="btn btn-info" type="submit">搜 索</button></span>
                </div>
            </form>
            <ul class="login_46f nav navbar-nav navbar-right" id="header-login"></ul>
        </nav>	</div>
</header>
<!-- /header -->
<div class="container body-content">
    <ol class="breadcrumb hidden-xs">
        <li><a href="/" title="<?=SITE_NAME?>"><i class="glyphicon glyphicon-home fs-14" aria-hidden="true"></i> 首页</a></li>
        <li><a href="<?=$infoarr['0']['sort_url']?>"><?=$sortname?></a></li>
        <li><a href="<?=$info_url?>"><?=$articlename?></a></li>
        <li class="active"><?=$chaptername?></li>
        <span class="pull-right" id="ReadSet"></span>
    </ol>
    <div class="panel panel-default" id="content">
        <div class="text-center visible-xs" id="mReadSet"></div>
        <div class="page-header text-center">
            <h1 class="readTitle"><?=$chaptername?></h1>
            <p class="text-center booktag">
                <a class="blue" href="<?=$info_url?>"><i class="glyphicon glyphicon-book fs-12" aria-hidden="true"></i> <?=$articlename?></a>
                <a class="blue" href="/author/<?=$author?>" title="<?=$author?>"><i class="glyphicon glyphicon-user fs-12" aria-hidden="true"></i> <?=$author?></a>
                <a class="red" href="javascript:addbookcase('<?=$articleid?>','<?=$articlename?>','<?=$chapterid?>','<?=$chaptername?>');" rel="nofollow" id="a_addbookcase"><i class="glyphicon glyphicon-heart-empty fs-12" aria-hidden="true"></i> 加入书签</a>
                <a href="javascript:report();" class="red errorlink"><i class="glyphicon glyphicon-remove-circle fs-12" aria-hidden="true"></i> 错误举报</a>			</p>
        </div>
        <div class="panel-body" id="rtext">
            <p><?=$author?>提示您：看后求收藏（<?=$chaptername?>,<?=$articlename?>,<?=$author?>,<?=SITE_NAME?>），接着再看更方便。</p>
            <div id="booktxt"><p>请关闭浏览器的阅读/畅读/小说模式并且关闭广告屏蔽过滤功能，避免出现内容无法显示或者段落错乱。</p>
                <?=$rico_content?>
            </div>
            <p>本章未完，点击下一页继续阅读。</p>
            <div class="text-center"><a href="javascript:report();" style="color: #ff0000;"><i class="glyphicon glyphicon-remove-circle fs-12" aria-hidden="true"></i> 章节报错(免登录)</a></div>
        </div>
        <div class="readPager">
            <!-- 上一页/上一章 -->
            <?php if($prevpage_url != ''): ?>
                <a id="linkPrev" href="<?=$prevpage_url?>"><i class="glyphicon glyphicon-backward" aria-hidden="true"></i> 上一页</a>
            <?php else: ?>
                <?php if($pre_cid == 0): ?><a id="linkPrev" href="#" title=""><i class="glyphicon glyphicon-backward" aria-hidden="true"></i> 无上章</a><?php else: ?><a id="linkPrev" href="<?=$pre_url?>"><i class="glyphicon glyphicon-backward" aria-hidden="true"></i> 上一章</a><?php endif ?>
            <?php endif ?>
            <!-- 返回目录 -->
            <a id="linkIndex" href="<?=$info_url?>" disable="disabled"><i class="glyphicon glyphicon-th-list" aria-hidden="true"></i> 目 录</a>
            <!-- 下一页/下一章 -->
            <?php if($nextpage_url != ''): ?>
                <a id="linkNext" href="<?=$nextpage_url?>">下一页 <i class="glyphicon glyphicon-forward" aria-hidden="true"></i></a>
            <?php else: ?>
                <?php if($next_cid == 0): ?><a rel="next" href="#" title="">无下章</a><?php else: ?><a id="linkNext" href="<?=$next_url?>">下一章 <i class="glyphicon glyphicon-forward" aria-hidden="true"></i></a><?php endif ?>
            <?php endif ?>
        </div>
        <p class="fs-12 text-muted text-center hidden-xs"><i class="glyphicon glyphicon-info-sign fs-14" aria-hidden="true"></i> 温馨提示：按 回车[Enter]键 返回书目，按[←]键 返回上一页， 按[→]键 进入下一页，加入书签方便您下次继续阅读。</p>
    </div>
    <div class="panel panel-default" id="content2">
        <div class="panel-heading">
            <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span> <?=$sortname?>小说相关阅读<a class="pull-right" href="<?=Sort::ss_sorturl($sortid)?>">More+</a>
        </div>
        <div class="panel-body">
            <div class="row">
                <?php foreach($neighbor as $k => $v): ?><?php if($k < 6):?>
                <div class="col-xs-4 book-coverlist">
                    <div class="row">
                        <div class="col-sm-5">
                            <a href="<?=$site_url?><?=$v['info_url']?>" class="thumbnail" style="background-image:url(<?=$v['img_url']?>)"></a>
                        </div>
                        <div class="col-sm-7 pl0">
                            <div class="caption">
                                <h4 class="fs-16 text-muted"><a href="<?=$v['info_url']?>" title="<?=$v['articlename']?>"><?=$v['articlename']?></a></h4>
                                <small class="fs-14 text-muted"><?=$v['author']?></small>
                                <p class="fs-12 text-justify hidden-xs"><?=$v['intro_des']?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif ?><?php endforeach ?>
                <div class="clear"></div>
            </div>
        </div>
    </div>
    <p class="hidden-xs"><a href="<?=$info_url?>" title="<?=$articlename?>"><?=$articlename?></a>所有内容均来自互联网，<?=SITE_NAME?>只为原作者<?=$author?>的小说进行宣传。欢迎各位书友支持<?=$author?>并收藏<a href="<?=$info_url?>" title="<?=$articlename?>"><?=$articlename?>最新章节</a>。</p>
    <div class="clear"></div>
</div>
<?php require_once 'tpl_footer.php'; ?>
<script src="/static/<?=$theme_dir?>/js/pagetop.js?v=<?=date('Ymd', time())?>"></script>
<script src="/static/<?=$theme_dir?>/js/tempbookcase.js?v=<?=date('Ymd', time())?>"></script>
<script>
    ReadKeyEvent();
    var lastread=new LastRead();
    var date = new Date();
    var d = date.getDate();
    var m =  ("0" + (date.getMonth() + 1)).slice(-2);
    lastread.set('<?=$site_url?>/book/<?=$articleid?>','<?=$site_url?>/chapter/<?=$articleid?>/<?=$chapterid?>.html','<?=$articlename?>','<?=$chaptername?>','<?=$author?>',m+'-'+d,'');
    function report() {
        alert('反馈成功，我们会尽快处理，感谢您对本站的支持！');
    }
</script>
<script src="/static/<?=$theme_dir?>/js/user.js"></script>
<script src="/static/<?=$theme_dir?>/js/layer.js"></script>
</body>
</html>

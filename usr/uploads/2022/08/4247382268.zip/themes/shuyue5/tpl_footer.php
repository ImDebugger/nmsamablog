<?php if (!defined('__ROOT_DIR__')) exit; ?>
<!-- footer -->
<footer class="footer_46f text-center">
    <?php if($ShipSayLink['is_link']==1): ?><p class="hidden-xs">友情连接：<?=$link_html?></p><?php endif ?>
    <p class="hidden-xs">本站所有小说为转载作品，所有章节均由网友上传，转载至本站只是为了宣传本书让更多读者欣赏。</p>
    <p class="hidden-xs">Copyright &copy; <?=$year?> <?=SITE_NAME?> All Rights Reserved.</p>

    <?php if($ShipSayLink['is_link']==1): ?><p class="visible-xs">友情连接：<?=$link_html?></p><?php endif ?>
    <p class="visible-xs">本站所有小说均由程序自动从搜索引擎索引</p>
    <p class="visible-xs">Copyright &copy; <?=$year?> <?=SITE_NAME?></p>
    <div class="clear"></div>
</footer>
<div class="back-to-top" id="back-to-top" title='返回顶部'>
    <span class="glyphicon glyphicon-menu-up" aria-hidden="true"></span>
</div>
<script src="https://cdn.staticfile.org/jquery/1.9.1/jquery.min.js"></script>
<script src="https://cdn.staticfile.org/twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.org/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<script src="/static/<?=$theme_dir?>/js/common.js?v=<?=date('Ymd', time())?>"></script>
<?php include_once __ROOT_DIR__ . '/shipsay/configs/count.ini.php';foreach($count as $v) {if($v['enable'])echo $v['html'];}?>
</body>
</html>

<?php 
ss_void();
if(!file_exists(__THEME_DIR__.'/tpl_author.php'))Url::ss_errpage();
$author=$author_ft=urldecode($matches[1]);
$author=mb_convert_encoding($author, "UTF-8", "GBK");
$author_ft=mb_convert_encoding($author_ft, "UTF-8", "GBK");
if($is_ft)$author=Convert::jt2ft($author,1);
$sql=$rico_sql.'AND author = "'.$author.'" ORDER BY lastupdate DESC';
if(isset($redis)) {
	$res=$redis->ss_redis_getrows($sql,$cache_time);
} else {
	$res=$db->ss_getrows($sql);
}
$author_count=is_array($res)?count($res):0;
if($is_ft)$author=$author_ft;
require_once __THEME_DIR__.'/tpl_author.php';
<?php
$ShipSayFilter['is_filter'] = 0;
$ShipSayFilter['filter_ini'] = '
天才一秒记住$$$$更新最快♂
笔趣阁♂船说
';
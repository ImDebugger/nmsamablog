<?php
$ShipSayLink['is_link'] = 0; 
$ShipSayLink['link_ini'] = ' 
<a href="https://www.shipsay.com" target="_blank">船说CMS</a>
<a href="http://www.huaitui.com" target="_blank">海量源码分享</a>
';
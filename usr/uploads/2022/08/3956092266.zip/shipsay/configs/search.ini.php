<?php

$ShipSaySearch = [
    'delay' => 30 
    ,'limit' => 100
    ,'min_words' => 2
    ,'cache_time' => 86400
    ,'is_record' => 1
];
<?php
$ShipSayReport['on'] = false;
$ShipSayReport['delay'] = 30; 

<?php if (!defined('__ROOT_DIR__')) exit;
error_reporting(0);
date_default_timezone_set('Asia/ChongQing');
include_once __ROOT_DIR__ . '/shipsay/version.php';
define('SITE_NAME', '船说CMS');
$dbarr = [
     'host' => '107.151.148.86'
    ,'port' => '3306'
    ,'name' => '76wx'
    ,'user' => '76wx'
    ,'pass' => 'Ai5CzHywwwrYWWTw'
    ,'pconnect' => 0
];
$authcode = '';

$sys_ver = '1.7';
$root_dir = '';
$txt_url = 'http://www.76wx.com/files/article/txt';              
$remote_img_url = 'http://www.76wx.com/files/article/image';
$local_img = 0;            
$is_attachment = 0;    
$att_url = '';              
$site_url = '';
$use_gzip = 0;
$enable_down = 0;
$is_ft = 0; 
$cache_homepage = 0;
$cache_homepage_period = 1800;

$theme_dir = 'shipsay';
$is_3in1 = 0;
$commend_ids = '1, 2, 3, 4, 5, 6';
$category_per_page = 10;
$readpage_split_lines = 20;
$vote_perday = 3;
$count_visit = 0;

$fake_info_url = '/book/{aid}/';      
$fake_chapter_url = '/read/{aid}/{cid}.html';
$use_orderid = '0';
$fake_sort_url = '/sort/{sortid}/{pid}/';      
$fake_top = '/top.html';        
$fake_recentread = '/history.html';
$fake_indexlist = '/index/{aid}/{pid}/';  
$per_indexlist = 50;

//分类设置
$sortarr[1] = ['code' => 'xuanhuan', 'caption' => '玄幻魔法'];
$sortarr[2] = ['code' => 'wuxia', 'caption' => '武侠修真'];
$sortarr[3] = ['code' => 'dushi', 'caption' => '都市言情'];
$sortarr[4] = ['code' => 'lishi', 'caption' => '历史军事'];
$sortarr[5] = ['code' => 'kehuan', 'caption' => '科幻灵异'];
$sortarr[6] = ['code' => 'youxi', 'caption' => '游戏竞技'];
$sortarr[7] = ['code' => 'nvsheng', 'caption' => '女生耽美'];
$sortarr[8] = ['code' => 'qita', 'caption' => '其他类型'];

//redis缓存设置
$use_redis = 0;
$redisarr = [
     'host' => '127.0.0.1' 
    ,'port' => '6379' 
    ,'db' => '0'
    ,'pass' => ''
];
$home_cache_time = 600;        
$info_cache_time = 600;        
$category_cache_time = 600;
$cache_time = 600;                  

//ID混淆
$is_multiple = 0;
$ss_newid = '$id + 5';
function ss_newid($id){
    return $id + 5;
}
$ss_sourceid = '$id - 5';
function ss_sourceid($id){
    return $id - 5;
}

$is_langtail = 1;
$langtail_catch_cycle = 7;
$langtail_cache_time = 0;
$fake_langtail_info = '/books/{aid}/';
$fake_langtail_indexlist = '/indexs/{aid}/{pid}/';


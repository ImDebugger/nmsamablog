<?php
$ShipSayVersion = [
  'Ver' => 'V4.0.1',
  'Release' => '2021-4-20',
  'Site' => 'https://www.shipsay.com',
  'QQ' => [
    'group' => '249310348',
    'url' => 'https://shang.qq.com/wpa/qunwpa?idkey=16621e5a46f2a4d13465ef538ac03a28b5664466ad32b164319f8034d38fda80'
   ]
];
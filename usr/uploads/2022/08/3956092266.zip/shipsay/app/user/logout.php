<?php
setcookie('ss_userid',null,0,'/');
setcookie('ss_username',null,0,'/');
setcookie('ss_password',null,0,'/');
setcookie('ss_groupid',null,0,'/');
header('Location: /');
?>
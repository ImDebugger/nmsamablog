<?php
/* 船说CMS极致精简服务器端(杰奇版) 
   QQ群: 249310348
   本文件不做修改
*/
$jieqiSort['article'][1] = array('code' => 'shipsay', 'caption' => '船说CMS'); 
<?php
$jieqiConfigs['article'] = array (
  'txtdir' => 'txt',
  'txturl' => '',

  'opfdir' => 'txt',
  'opfurl' => '',

  'htmldir' => 'html',
  'htmlurl' => '',

  'fulldir' => 'fulltext',
  'fullurl' => '',
  
  'imagedir' => 'image',
  'imageurl' => '',
  
  'attachdir' => 'attachment',
  'attachurl' => '',
);
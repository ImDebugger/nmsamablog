<?php if (!defined('__ROOT_DIR__')) exit; ?>
<!-- footer -->
<div class="container">
    <div class="footer gray">
        <p>本站所有小说为转载作品，所有章节均由网友上传，转载至本站只是为了宣传本书让更多读者欣赏。</p>
        <p>Copyright <?=$year?> <?=SITE_NAME?> All Rights Reserved.</p>
    </div>
</div>
<script>setEcho();</script>
</body>
</html>